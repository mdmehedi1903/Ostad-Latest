use("CraftShop")


// db.employees.find()
db.employees.findOne(
    {salary:75000},

)