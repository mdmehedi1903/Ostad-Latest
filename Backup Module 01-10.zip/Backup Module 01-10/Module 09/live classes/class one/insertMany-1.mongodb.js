use('names');


// db.brands.insertMany(
//     [

//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"},
//            { "name": "mehedi"}

//     ]
// )


db.brands.insert(
    [

           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"},
           { "name": "robi"}

    ]
)
