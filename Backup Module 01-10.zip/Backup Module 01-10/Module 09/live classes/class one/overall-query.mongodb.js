use('names')





// db.brands.updateOne(
//     {name: "abdul"},
//     {$set:{
//         salary: 3500
//     }}
// )

// //delete by object
// db.brands.deleteOne(
//     {_id: ObjectId("683826439fa75b95d3957b60")}
// )

// db.brands.distinct('name')
//just unqique

///sorting
// db.brands.find().sort(
//     {salary: 1}
// ).limit(2)


// db.brands.find().sort(
//     {salary: -1}
// ).limit(2)

