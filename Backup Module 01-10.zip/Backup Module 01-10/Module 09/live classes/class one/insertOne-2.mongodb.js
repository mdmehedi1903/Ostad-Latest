use('names');




db.brands.insertOne(
    {"name": "Gazi"}
)