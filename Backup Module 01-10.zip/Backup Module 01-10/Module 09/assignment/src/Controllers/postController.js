exports.create = async (req, res) => { 

    res.status(200).json({status: "Success!"})

};

exports.read = async (req, res) => { 

    res.status(200).json({status: "Success!"})
};

exports.delete = async (req, res) => {
    res.status(200).json({status: "Success!"})
 };

exports.update = async (req, res) => {
    res.status(200).json({status: "Success!"})
 };