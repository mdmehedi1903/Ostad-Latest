let myMap = new Map();

myMap.set("name", "Mehedi");
myMap.set("age", "30");
myMap.set("district", "dhaka");


console.log(myMap.keys())
console.log(myMap.values())