
var sum = 0;
for(i=0;i<=10;i++){
    sum = sum+i;
    
}

console.log(sum)