"use strict";

function myName(){
    Myname = "Emam Mehedi";
}

myName()