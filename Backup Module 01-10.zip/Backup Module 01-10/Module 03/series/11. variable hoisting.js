myName = "Emam Mehedi";
console.log(myName);

var myName;