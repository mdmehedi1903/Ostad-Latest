class myClass {
    age = 40;
    static name = "Emam Mehedi";
    static myAdd(a,b){
        let result = a+b
        console.log(result)
    }
}

myClass.myAdd(1,2)
console.log(myClass.name)