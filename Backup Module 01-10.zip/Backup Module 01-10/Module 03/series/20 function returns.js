// return
function myFun(){
    return 5000;
}
function something(){
   return myFun();
}

console.log(something())