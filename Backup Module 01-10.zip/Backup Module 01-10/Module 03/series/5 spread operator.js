let richCountry = ["CHINA", "EUROPE", "USA"]
let poorCountry = [...richCountry,"India", "BD", "Pakistan"]



console.log("All Country: "+poorCountry)