var mySet = new Set();
var mySet1 = new Set(["A", "B", "C"]);

mySet.add('Bangladesh')
mySet.add('Bangladesh')
mySet.add('India')
mySet.add('Nepal')
mySet.add('Nepal')

// mySet.clear()
// mySet.delete('Bangladesh')
// console.log(mySet.has('Bangladesh'))
console.log(mySet.size)
console.log(mySet.values())

console.log(mySet)
console.log(mySet1)

