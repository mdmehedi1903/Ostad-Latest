let myDetails = {
    names:"Mehedi",
    age:"30",
    year:"2003",
}

for (props in myDetails) {
    console.log(props+ `:=====❤  ${myDetails[props]}`)
}

console.log("5"==5);
console.log("5"===5);