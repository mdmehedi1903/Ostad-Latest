let myLaptop = "Dell, HP";

function myFun(){
    console.log("My Fun One")
}
function myFun1(){
    console.log("My Fun Two")
}

export {myLaptop,myFun, myFun1}