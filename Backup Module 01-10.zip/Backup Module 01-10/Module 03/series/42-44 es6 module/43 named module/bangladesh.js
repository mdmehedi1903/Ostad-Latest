import {myLaptop, myFun, myFun1} from "./china.js";

console.log(myLaptop);
myFun()
myFun1()