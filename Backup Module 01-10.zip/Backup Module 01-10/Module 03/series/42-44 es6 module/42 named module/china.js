let myLaptop = "Dell, HP";

export {myLaptop}