import {myLaptop} from "./china.js";

console.log(myLaptop);