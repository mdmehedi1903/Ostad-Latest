class Toys {
    myToys(){
        alert("Toys Imported!")
    }
}

export {Toys};