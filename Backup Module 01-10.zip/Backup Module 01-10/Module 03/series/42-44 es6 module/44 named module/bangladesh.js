import {Toys} from "./china.js";

let obj = new Toys();
obj.myToys()