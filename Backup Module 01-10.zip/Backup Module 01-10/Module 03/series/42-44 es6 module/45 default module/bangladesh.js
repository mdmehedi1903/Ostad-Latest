import MalSaman from "./china.js";

let obj = new MalSaman();
obj.myToys()