class Toys {
    myToys(){
        alert("Toys Imported!")
    }
}

export default Toys;