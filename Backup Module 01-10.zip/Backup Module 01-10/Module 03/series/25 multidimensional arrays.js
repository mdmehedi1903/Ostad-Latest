var bangladesh = ["Dhaka", "Chittagong", "Barisal"];
var india = ["Delhi", "Mumbai", "Kolkata"];
var china = ["Beijing", "Shanghai", "Guangzhou"];

var asia = [bangladesh, india, china];

console.log(asia[1][1]); // Output: Mumbai
