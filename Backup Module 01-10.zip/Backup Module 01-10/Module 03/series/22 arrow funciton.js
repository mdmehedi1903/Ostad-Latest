let myArrow = (x, ...y)=> {
    return x+y;
}

console.log(myArrow("How are you?", 1,2,3,4))


