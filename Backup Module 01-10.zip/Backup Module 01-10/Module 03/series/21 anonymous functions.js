var myFun = function(msg) {
    console.log(msg)
}

var myFun = function(msg){ // reassign as like variable
    console.log(msg+" here")
}



myFun("Your message")