let person = {
    myName: "Bill Gates",
    age: 30,
    smile: true,
    action: ()=> {
        return "This is my action!";
    }
}


console.log(person.action())