// simple functions

function myName(msg){
    console.log(msg)
}


myName("hello simple function")