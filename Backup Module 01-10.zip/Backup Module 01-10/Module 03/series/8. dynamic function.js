let myFun = function(holdPara){
    return holdPara;
}

console.log(myFun("Emam Mehedi"))