// var keyword: var keyword can redeclaire and reassign
// let keyword: let keyword can reassign but not redeclaire
// const keyword: const cannot reassign and redeclaire

// const
const myName = "Mehedi"

// let
let Yourname = "Mehedi"
//let Yourname = "Mehedi" // redeclaire is not work
Yourname = "Mehedi" // reassign

var herName = "Mehedi"
var herName = "Gazi" // redeclaire
herName = "Motaer" // reassign

console.log(myName)