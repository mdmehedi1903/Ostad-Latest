class myClass {
    constructor(msg){
        console.log(msg)
    }
    myFun(){
        console.log("How are you?")
    }
    myFun2(){
        console.log("How are you?")
    }
    myFun3(){
        console.log("How are you?")
    }
}

// let myFunny = new myClass("I'm constructor!");
myClass("I'm constructor!");

myFunny.myFun2()