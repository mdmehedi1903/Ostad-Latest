// if 
// else if
// else