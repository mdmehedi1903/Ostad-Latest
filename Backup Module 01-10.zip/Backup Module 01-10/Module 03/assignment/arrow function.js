const calculateSquare = a=>a*a;
console.log(calculateSquare(5))