


function mergeArrays(){
    let arry3 = [...arr1, ...arr2]
    return arry3;
}


let arr1 = [1,2,3]
let arr2 = [4,5,6]

console.log(mergeArrays(arr1, arr2))