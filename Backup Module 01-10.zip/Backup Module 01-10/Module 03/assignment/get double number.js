function doubleNumbers(arr){
    return arr.map(a=> a*a)
 } 
 
 let numbers = [1,2,3,4,5,6] 
 console.log(doubleNumbers(numbers))