class MathUtitlity {
    static action(a,b){
        return a+b;
    }
}

console.log(MathUtitlity.action(1,2))