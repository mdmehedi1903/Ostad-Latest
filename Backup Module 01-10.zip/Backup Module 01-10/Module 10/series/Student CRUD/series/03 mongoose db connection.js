// connection by rabbil code 

// let URI = "mongodb://localhost:27017/mehedi";
// let Options = {user:"", pass:""} 

// mongoose.connect(URI, Options, (error)=> {
//     console.log("DB Connected!")
//     console.log(error)
// })