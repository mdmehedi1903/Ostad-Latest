export * as mycalc from "./calc.js";
export {default as yourAre}  from "./whoiam.js"