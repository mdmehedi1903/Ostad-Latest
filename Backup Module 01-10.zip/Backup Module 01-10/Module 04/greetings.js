const myGreeting = ()=>{
    console.log("Welcome! How are you?")
}

const myWelcome = ()=>{
    console.log("What is your name?")
}

export {myGreeting as Greet, myWelcome};