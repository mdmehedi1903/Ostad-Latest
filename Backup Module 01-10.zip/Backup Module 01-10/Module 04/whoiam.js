const myName = "I'm Mehedi";
export default myName;


