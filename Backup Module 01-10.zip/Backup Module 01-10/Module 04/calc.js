export const sum=(a,b)=>{
    return a+b;
}

export const sub =(a,b)=> {
    return a-b;
}

const multiply = (a,b)=> {
    return a*b;
}

const divide = (a,b)=> {
    return a/b;
}

export {multiply, divide}