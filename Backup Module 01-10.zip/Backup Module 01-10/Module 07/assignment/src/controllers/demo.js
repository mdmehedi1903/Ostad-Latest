exports.demo = (req,res)=> {
    res.send("Hello Programme!")
}