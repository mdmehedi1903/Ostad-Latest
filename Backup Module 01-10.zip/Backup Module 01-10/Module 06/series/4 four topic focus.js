// req 
// res
// middleware
// database operations