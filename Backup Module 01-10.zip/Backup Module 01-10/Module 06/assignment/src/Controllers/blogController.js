exports.create = (req,res)=> {
    res.send("Blog create!")
}


exports.read = (req,res)=> {
    res.send("Blog read!")
}


exports.update = (req,res)=> {
    res.send("Blog update!")
}

exports.delete = (req,res)=> {
    res.send("Blog delete!")
}