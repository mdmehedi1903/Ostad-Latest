exports.demo=(req,res)=> {
    res.send("<h1>Hello word!</h1>")
}