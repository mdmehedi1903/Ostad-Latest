module.exports = (req,res)=> {
    res.send("Hello")
}